﻿/*
************************************************************
* COMPILERS COURSE - Algonquin College
* Code version: Fall, 2024
* Author: TO_DO
* Professors: Paulo Sousa
************************************************************
#
# "=---------------------------------------="
# "|  COMPILERS - ALGONQUIN COLLEGE (F24)  |"
# "=---------------------------------------="
# "    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@    ”
# "    @@                             @@    ”
# "    @@           %&@@@@@@@@@@@     @@    ”
# "    @@       @%% (@@@@@@@@@  @     @@    ”
# "    @@      @& @   @ @       @     @@    ”
# "    @@     @ @ %  / /   @@@@@@     @@    ”
# "    @@      & @ @  @@              @@    ”
# "    @@       @/ @*@ @ @   @        @@    ”
# "    @@           @@@@  @@ @ @      @@    ”
# "    @@            /@@    @@@ @     @@    ”
# "    @@     @      / /     @@ @     @@    ”
# "    @@     @ @@   /@/   @@@ @      @@    ”
# "    @@     @@@@@@@@@@@@@@@         @@    ”
# "    @@                             @@    ”
# "    @@         S O F I A           @@    ”
# "    @@                             @@    ”
# "    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@    ”
# "                                         "
# "[READER SCRIPT .........................]"
# "                                         "
*/


/*
************************************************************
* File name: Parser.c
* Compiler: MS Visual Studio 2022
* Course: CST 8152 – Compilers, Lab Section: [011, 012]
* Assignment: A32.
* Date: May 01 2023
* Purpose: This file contains all functionalities from Parser.
* Function list: (...).
************************************************************
*/

/* TO_DO: Adjust the function header */

#ifndef COMPILERS_H_
#include "Compilers.h"
#endif

#ifndef PARSER_H_
#include "Parser.h"
#endif

/* Parser data */
extern ParserData psData; /* BNF statistics */

/*
************************************************************
 * Process Parser
 ***********************************************************
 */
/* TO_DO: This is the function to start the parser - check your program definition */

voids startParser() {
	/* TO_DO: Initialize Parser data */
	num_i i = 0;
	for (i = 0; i < NUM_BNF_RULES; i++) {
		psData.parsHistogram[i] = 0;
	}
	/* Proceed parser */
	lookahead = tokenizer();

	/* Handle initial errors immediately if the first token is invalid */
	if (lookahead.code == ERROR_TOKEN) {
		printError();
		exit(EXIT_FAILURE);
	}

	if (lookahead.code != SOURCE_END_OF_FILE) {
		program();
	}
	matchToken(SOURCE_END_OF_FILE, NO_ATTR);
	printf("%s%s\n", STR_LANGNAME, ": Source file parsed");
}


/*
 ************************************************************
 * Match Token
 ***********************************************************
 */
/* TO_DO: This is the main code for match - check your definition */
voids matchToken(num_i tokenCode, num_i tokenAttribute) {
	num_i matchFlag = 1;
	/* Check if current token matches the expected token */
	switch (lookahead.code) {
	case KEY_T:
	case ARITHMETIC_OPERATOR:
	case RELATIONAL_OPERATOR:
	case LOGICAL_OPERATOR:
		if (lookahead.attribute.codeType != tokenAttribute) {
			matchFlag = 0;
		}
		break;
	default:
		if (lookahead.code != tokenCode) {
			matchFlag = 0;
		}
		break;
	}
	/* Print current token code for debugging */
	//printf("lookahead.code = %d\n", lookahead.code);
	/* If match, advance to next token */
	if (matchFlag) {
		if (lookahead.code == SOURCE_END_OF_FILE) {
			return;
		}
		lookahead = tokenizer();
		if (lookahead.code == ERROR_TOKEN) {
			printError();
			lookahead = tokenizer();
			syntaxErrorNumber++;
		}
	}
	else {
		/* If no match, handle synchronization error */
		syncErrorHandler(tokenCode);
	}
}

/*
 ************************************************************
 * Syncronize Error Handler
 ***********************************************************
 */
/* TO_DO: This is the function to handler error - adjust basically datatypes */
voids syncErrorHandler(num_i syncTokenCode) {
	printError();
	syntaxErrorNumber++;
	while (lookahead.code != syncTokenCode) {
		if (lookahead.code == SOURCE_END_OF_FILE) {
			exit(syntaxErrorNumber);
		}
		lookahead = tokenizer();
	}
	if (lookahead.code != SOURCE_END_OF_FILE) {
		lookahead = tokenizer();
	}
}

/*
 ************************************************************
 * Print Error
 ***********************************************************
 */
/* TO_DO: This is the function to error printing - adjust basically datatypes */
voids printError() {
	extern numParserErrors;			/* link to number of errors (defined in Parser.h) */
	Token t = lookahead;
	printf("%s%s%3d\n", STR_LANGNAME, ": Syntax error:  Line:", line);
	printf("*****  Token code:%3d Attribute: ", t.code);
	switch (t.code) {
	case ERROR_TOKEN:
		printf("*ERROR*: %s\n", t.attribute.errLexeme);
		break;
	case SOURCE_END_OF_FILE:
		printf("SEOF_T\t\t%d\t\n", t.attribute.seofType);
		break;
	case METHOD_NAME_ID:
		printf("MNID_T:\t\t%s\t\n", t.attribute.idLexeme);
		break;
	case STRING_LITERAL:
		printf("STR_T: %s\n", readerGetContent(stringLiteralTable, t.attribute.contentString));
		break;
	case KEY_T:
		printf("KW_T: %s\n", keywordTable[t.attribute.codeType]);
		break;
	case LEFT_PARENTHESIS:
		printf("LPR_T\n");
		break;
	case RIGHT_PARENTHESIS:
		printf("RPR_T\n");
		break;
	case LEFT_BRACE:
		printf("LBR_T\n");
		break;
	case RIGHT_BRACE:
		printf("RBR_T\n");
		break;
	case END_OF_STATEMENT:
		printf("NA\n");
		break;
	case ARITHMETIC_OPERATOR:
		printf("ARITHMETIC_OPERATOR: code:%d\n", t.attribute.arithmeticOperator);
		break;
	case VARIABLE_TOKEN:
		printf("VARIABLE_TOKEN:\t%s\n", t.attribute.idLexeme);
		break;
	default:
		printf("%s%s%d\n", STR_LANGNAME, ": Scanner error: invalid token code: ", t.code);
		numParserErrors++; // Updated parser error
	}
}

/*
 ************************************************************
 * Program statement
 * BNF: <program> -> mainF { <opt_statements> }
 * FIRST(<program>)= {CMT_T, MNID_T (mainF), SEOF_T}.
 ***********************************************************
 */

voids program() {
	psData.parsHistogram[BNF_program]++;
	// Handle comments
	while (lookahead.code == COMMENT) {
		comment();
	}

	if (lookahead.code == METHOD_NAME_ID &&
		strcmp(lookahead.attribute.idLexeme, "mainF") == 0) {
		matchToken(METHOD_NAME_ID, NO_ATTR);
		matchToken(LEFT_PARENTHESIS, NO_ATTR);
		matchToken(RIGHT_PARENTHESIS, NO_ATTR);
		matchToken(LEFT_BRACE, NO_ATTR);

		// Parse variable declarations
		varDeclarations();
		// Parse statements until }
		optionalStatements();

		matchToken(RIGHT_BRACE, NO_ATTR);
	}
	else {
		printError();
	}

	printf("%s%s\n", STR_LANGNAME, ": Program parsed");
}


/*
 ************************************************************
 * comment
 * BNF: comment
 * FIRST(<comment>)= {COMMENT}.
 ***********************************************************
 */
voids comment() {
	psData.parsHistogram[BNF_comment]++;
	matchToken(COMMENT, NO_ATTR);
	printf("%s%s\n", STR_LANGNAME, ": Comment parsed");
}

/*
 ************************************************************
 * Optional Var List Declarations
 * BNF: <opt_varlist_declarations> -> <varlist_declarations> | e
 * FIRST(<opt_varlist_declarations>) = { e, KW_T (KW_int), KW_T (KW_real), KW_T (KW_string)}.
 ***********************************************************
 */
voids optVarListDeclarations() {
	psData.parsHistogram[BNF_optVarListDeclarations]++;
	// Loop to parse variable declarations
	while (lookahead.code == KEY_T && (
		strcmp(keywordTable[lookahead.attribute.codeType], "num_i") == 0 ||
		strcmp(keywordTable[lookahead.attribute.codeType], "num_f") == 0 ||
		strcmp(keywordTable[lookahead.attribute.codeType], "num_d") == 0 ||
		strcmp(keywordTable[lookahead.attribute.codeType], "num_l") == 0 ||
		strcmp(keywordTable[lookahead.attribute.codeType], "num_u") == 0 ||
		strcmp(keywordTable[lookahead.attribute.codeType], "bol") == 0 ||
		strcmp(keywordTable[lookahead.attribute.codeType], "word_c") == 0 ||
		strcmp(keywordTable[lookahead.attribute.codeType], "word_s") == 0)) {
		// Match type keyword
		matchToken(KEY_T, lookahead.attribute.codeType);
		// Match first variable
		if (lookahead.code == VARIABLE_TOKEN) {
			matchToken(VARIABLE_TOKEN, NO_ATTR);
			fltVariableIdentifier();
			// Handle variable list
			while (lookahead.code == COMMA) {
				matchToken(COMMA, NO_ATTR);
				if (lookahead.code == VARIABLE_TOKEN) {
					matchToken(VARIABLE_TOKEN, NO_ATTR);
				}
				else {
					printError();
					break;
				}
			}
			matchToken(END_OF_STATEMENT, NO_ATTR); // Match ';'
		}
		else {
			printError();
			break;
		}
	}
	printf("%s%s\n", STR_LANGNAME, ": Optional Variable List Declarations parsed");
}

/* TO_DO: Continue the development (all non-terminal functions) */

/*
 ************************************************************
 * Optional statement
 * BNF: <opt_statements> -> <statements> | ϵ
 * FIRST(<opt_statements>) = { ϵ , IVID_T, FVID_T, SVID_T, KW_T(KW_if),
 *				KW_T(KW_while), MNID_T(print&), MNID_T(input&) }
 ***********************************************************
 */
voids optionalStatements() {
	psData.parsHistogram[BNF_optionalStatements]++;
	while (isStatementStarter()) {
		statement();
	}
	printf("%s%s\n", STR_LANGNAME, ": Optional statements parsed");
}

/*
 ************************************************************
 * Statements
 * BNF: <statements> -> <statement><statementsPrime>
 * FIRST(<statements>) = { IVID_T, FVID_T, SVID_T, KW_T(KW_if),
 *		KW_T(KW_while), MNID_T(input&), MNID_T(print&) }
 ***********************************************************
 */
voids statements() {
	psData.parsHistogram[BNF_statements]++;
	statement();
	statementsPrime();
	printf("%s%s\n", STR_LANGNAME, ": Statements parsed");
}

/*
 ************************************************************
 * Statements Prime
 * BNF: <statementsPrime> -> <statement><statementsPrime> | ϵ
 * FIRST(<statementsPrime>) = { ϵ , IVID_T, FVID_T, SVID_T, 
 *		KW_T(KW_if), KW_T(KW_while), MNID_T(input&), MNID_T(print&) }
 ***********************************************************
 */
voids statementsPrime() {
	psData.parsHistogram[BNF_statementsPrime]++;
	switch (lookahead.code) {
	case METHOD_NAME_ID:
		if (strncmp(lookahead.attribute.idLexeme, LANG_WRTE, 6) == 0) {
			statements();
			break;
		}
	default:
		; //empty string
	}
}

/*
 ************************************************************
 * Single statement
 * BNF: <statement> -> <assignment statement> | <selection statement> |
 *	<iteration statement> | <input statement> | <output statement>
 * FIRST(<statement>) = { IVID_T, FVID_T, SVID_T, KW_T(KW_if), KW_T(KW_while),
 *			MNID_T(input&), MNID_T(print&) }
 ***********************************************************
 */
voids statement() {
	psData.parsHistogram[BNF_statement]++;
	if (lookahead.code == VARIABLE_TOKEN) {
		// Assignment statement
		matchToken(VARIABLE_TOKEN, NO_ATTR);
		matchToken(ASSIGNMENT, NO_ATTR);
		// Parse expression inline
		parseExpression();
		matchToken(END_OF_STATEMENT, NO_ATTR);
	}
	else if (lookahead.code == METHOD_NAME_ID &&
		strcmp(lookahead.attribute.idLexeme, "inputF") == 0) {
		// Input statement: inputF("Enter a number");
		matchToken(METHOD_NAME_ID, NO_ATTR);
		matchToken(LEFT_PARENTHESIS, NO_ATTR);

		// Expect a STRING_LITERAL as the argument to inputF()
		if (lookahead.code == STRING_LITERAL) {
			matchToken(STRING_LITERAL, NO_ATTR);
		}
		else {
			printError();
			// Consume one token to avoid infinite loop:
			lookahead = tokenizer();
		}

		matchToken(RIGHT_PARENTHESIS, NO_ATTR);
		matchToken(END_OF_STATEMENT, NO_ATTR);
	}
	else if (lookahead.code == METHOD_NAME_ID &&
		strcmp(lookahead.attribute.idLexeme, "printF") == 0) {
		// Output statement
		outputStatement();
	}
	else {
		printError();
		// Consume one token here to ensure progress:
		lookahead = tokenizer();
	}
	printf("%s%s\n", STR_LANGNAME, ": Statement parsed");
}

/*
 ************************************************************
 * Output Statement
 * BNF: <output statement> -> print& (<output statementPrime>);
 * FIRST(<output statement>) = { MNID_T(print&) }
 ***********************************************************
 */
voids outputStatement() {
	psData.parsHistogram[BNF_outputStatement]++;
	matchToken(METHOD_NAME_ID, NO_ATTR); // `printF`
	matchToken(LEFT_PARENTHESIS, NO_ATTR);
	// Directly allow either STRING_LITERAL or VARIABLE_TOKEN
	if (lookahead.code == STRING_LITERAL) {
		matchToken(STRING_LITERAL, NO_ATTR);
	}
	else if (lookahead.code == VARIABLE_TOKEN) {
		matchToken(VARIABLE_TOKEN, NO_ATTR);
	}
	else {
		printError();
	}
	matchToken(RIGHT_PARENTHESIS, NO_ATTR);
	matchToken(END_OF_STATEMENT, NO_ATTR);
	printf("%s%s\n", STR_LANGNAME, ": Output statement parsed");
}

/*
 ************************************************************
 * Output Variable List
 * BNF: <opt_variable list> -> <variable list> | ϵ
 * FIRST(<opt_variable_list>) = { IVID_T, FVID_T, SVID_T, ϵ }
 ***********************************************************
 */
voids outputVariableList() {
	psData.parsHistogram[BNF_outputVariableList]++;
	switch (lookahead.code) {
	case STRING_LITERAL:
		matchToken(STRING_LITERAL, NO_ATTR);
		break;
	default:
		;
	}
	printf("%s%s\n", STR_LANGNAME, ": Output variable list parsed");
}

/*
 ************************************************************
 * The function prints statistics of BNF rules
 * Param:
 *	- Parser data
 * Return:
 *	- Void (procedure)
 ***********************************************************
 */
/*
sofia_void printBNFData(ParserData psData) {
}
*/
voids printBNFData(ParserData psData) {
	/* Print Parser statistics */
	printf("Statistics:\n");
	printf("----------------------------------\n");
	int cont = 0;
	for (cont = 0; cont < NUM_BNF_RULES; cont++) {
		if (psData.parsHistogram[cont] > 0)
			printf("%s%s%s%d%s", "Token[", BNFStrTable[cont], "]=", psData.parsHistogram[cont], "\n");
	}
	printf("----------------------------------\n");
}

/* My functions */

num_i isStatementStarter() {
	if (lookahead.code == VARIABLE_TOKEN || // Assignment statements
		(lookahead.code == METHOD_NAME_ID &&
			(strcmp(lookahead.attribute.idLexeme, "printF") == 0 ||
				strcmp(lookahead.attribute.idLexeme, "inputF") == 0))) {
		return TRUE;
	}
	return FALSE;
}

voids parseExpression() {
	parseTerm();
	while (lookahead.code == ARITHMETIC_OPERATOR &&
		(lookahead.attribute.arithmeticOperator == OP_ADD ||
			lookahead.attribute.arithmeticOperator == OP_SUB)) {
		matchToken(ARITHMETIC_OPERATOR, lookahead.attribute.arithmeticOperator);
		parseTerm();
	}
}

voids parseFactor() {
	if (lookahead.code == STRING_LITERAL) {
		matchToken(STRING_LITERAL, NO_ATTR);
		primaryArithmeticExpression();
	}
	else if (lookahead.code == VARIABLE_TOKEN ||
		lookahead.code == FLOAT_LITERAL ||
		lookahead.code == INTEGER_LITERAL) {
		matchToken(lookahead.code, NO_ATTR);
		primaryArithmeticExpression();
	}
	else if (lookahead.code == LEFT_PARENTHESIS) {
		matchToken(LEFT_PARENTHESIS, NO_ATTR);
		parseExpression();
		matchToken(RIGHT_PARENTHESIS, NO_ATTR);
		primaryArithmeticExpression();
	}
	else if (lookahead.code == METHOD_NAME_ID &&
		strcmp(lookahead.attribute.idLexeme, "inputF") == 0) {
		// Handle inputF(...) as a factor in an expression
		matchToken(METHOD_NAME_ID, NO_ATTR);
		matchToken(LEFT_PARENTHESIS, NO_ATTR);
		if (lookahead.code == STRING_LITERAL) {
			matchToken(STRING_LITERAL, NO_ATTR);
		}
		else {
			printError();
			lookahead = tokenizer(); // consume token to avoid loops
		}
		matchToken(RIGHT_PARENTHESIS, NO_ATTR);
		// After inputF(...) call, treat it as a primary arithmetic expression
		primaryArithmeticExpression();
	}
	else {
		printError();
		lookahead = tokenizer(); // consume token to avoid infinite loops
	}
}

voids parseTerm() {
	parseFactor();
	while (lookahead.code == ARITHMETIC_OPERATOR &&
		(lookahead.attribute.arithmeticOperator == OP_MUL ||
			lookahead.attribute.arithmeticOperator == OP_DIV)) {
		matchToken(ARITHMETIC_OPERATOR, lookahead.attribute.arithmeticOperator);
		parseFactor();
	}
	multiplicativeArithmeticExpression();
}

voids fltVariableIdentifier() {
	// Parse a float variable identifier here
	// When done:
	psData.parsHistogram[BNF_fltVariableIdentifier]++;
	printf("%s%s\n", STR_LANGNAME, ": Float Variable identifier parsed");
}

voids multiplicativeArithmeticExpression() {
	// Parse multiplicative arithmetic expression
	// When done:
	psData.parsHistogram[BNF_multiplicativeArithmeticExpression]++;
	printf("%s%s\n", STR_LANGNAME, ": Multiplicative arithmetic expression parsed");
}

voids primaryArithmeticExpression() {
	psData.parsHistogram[BNF_primaryArithmeticExpression]++;
	printf("%s%s\n", STR_LANGNAME, ": Primary arithmetic expression parsed");
}

voids varDeclarations() {
	// While current token is a type keyword (e.g., num_f)
	while (lookahead.code == KEY_T && isTypeKeyword(lookahead.attribute.codeType)) {
		matchToken(KEY_T, lookahead.attribute.codeType); // e.g., num_f

		// First variable
		matchToken(VARIABLE_TOKEN, NO_ATTR);
		printf("Sofia: Float Variable identifier parsed\n");

		// Additional variables separated by commas
		while (lookahead.code == COMMA) {
			matchToken(COMMA, NO_ATTR);
			matchToken(VARIABLE_TOKEN, NO_ATTR);
			printf("Sofia: Float Variable identifier parsed\n");
		}

		matchToken(END_OF_STATEMENT, NO_ATTR);
		printf("Sofia: Float Var List parsed\n");
	}
}

num_i isTypeKeyword(num_i codeType) {
	word_c* typeName = keywordTable[codeType];
	return (strcmp(typeName, "num_i") == 0 ||
		strcmp(typeName, "num_f") == 0 ||
		strcmp(typeName, "num_d") == 0 ||
		strcmp(typeName, "num_l") == 0 ||
		strcmp(typeName, "num_u") == 0 ||
		strcmp(typeName, "bol") == 0 ||
		strcmp(typeName, "word_c") == 0 ||
		strcmp(typeName, "word_s") == 0);
}
